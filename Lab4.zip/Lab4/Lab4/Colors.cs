public enum Colors
{
    Red, Blue, Green, White, Black, Grey, Ping, Orange, Yellow, Purpure
}